#!/bin/sh
#
#    Name:         Update_gzip.sh
#
#    Description:  Install the gzip package
#
#                  Relevant to the following:
#
#                    OpenTera      Original
#                                  Home Server
#                                  Pro v1
#                  Should also work for
#                    OpenLink      LS1
#                                  HG
#                  Designed to be called from a master script that is
#                  controlling the overall upgrade.  Assumes that the
#                  script is being called from the root of the image
#                  it is trying to update
#
#    Change History:
#	28 Feb 2010	itimpi	First Version for OpenTera v3 (gzip 1.3.12)
#	31 Mar 20101	itimpi	Updated for gzip 1.4

# The script can take one parameter which is the 'root' directory
# relative to which the changes must be applied.  If omitted then
# the update is relative to /


BASEDIR=$1

PACKAGE="gzip-1.4_ppc.tgz"

echo ""
echo "*************************************************************"
echo "****** ${PACKAGE} Install Starting"
echo "*************************************************************"
echo ""


#---------------- main package install ----------------
#	We use an unpack/copy technique to avoid clobbering
#	any directory symbolic links that might exist in target
#	(this is one way of freeing space on system partition)

echo "[INFO] Processing ${PACKAGE} archive"
echo "[INFO] unpacking ..."
mkdir temp
tar -xzf ${PACKAGE} --directory=temp
echo "[INFO] installing ..."
for d in `ls temp`
do
	cp -pr temp/$d/* ${BASEDIR}/usr/local/$d
done
echo "[INFO] tidying up ..."
rm -fr temp

# We remove any existing binaries in /bin and set up
# symbolic links to the new versions in /usr/local/bin
# This will keep any scripts with absolute paths happy.

PWD_SAVE=`pwd`
cd $1/bin
rm -f gzip 
rm -f gunzip
rm -f uncompress
ln -s /usr/local/bin/gzip gzip
ln -s /usr/local/bin/gunzip gunzip
ln -s /usr/local/bin/uncompress uncompress
cd ${PWD_SAVE}

echo ""
echo "*************************************************************"
echo "****** ${PACKAGE} Install Completed"
echo "*************************************************************"
echo ""


#!/bin/sh
#
#    Name:         Update_grep.sh
#
#    Description:  Implement the latest GNU grep for the following
#
#                    OpenTera      Original
#                                  Home Server
#                                  Pro
#                  Should also work for
#                    OpenLink      LS1
#                                  HG
#                  Designed to be called from a master script that is
#                  controlling the overall upgrade.  Assumes that the
#                  script is being called from the root of the image
#                  it is trying to update
#
#    Change History:
#       02 Mar 2010	itimpi	     first version for OpenTera v3 (grep 2.5.4)
#       31 Mar 2010	itimpi	     Updated for grep 2.6.2
#	27 Apr 2010	itimpi	     Update script now version independent.

# The script can take one parameter which is the 'root' directory
# relative to which the changes must be applied.  If omitted then
# the update is relative to /

BASEDIR=$1

# Version of the busybox binary that this script relates to.
# This is a check to avoid setting up links that are not
# appropriate for a particular build of the busybox binary.

PACKAGE=`ls grep*.tgz`

echo ""  
echo "*********************************************************************"
echo "****** ${PACKAGE} upgrade starting"
echo "*********************************************************************"
echo ""
echo "[INFO] BASEDIR=/$BASEDIR"/
echo "[INFO] PACKAGE=$PACKAGE"
echo ""

#----------------------------------------------------------------------------
#	Install the new binary and its associated links
#	We use a extract/copy method to avoid destroying
#	any symbolic links on the destination.
#----------------------------------------------------------------------------

echo "[INFO] unpacking ${PACKAGE} archive..."
mkdir temp
tar -xzf ${PACKAGE} --directory=temp
echo "[INFO] installing ..."
for d in `ls temp`
do
	cp -pr temp/$d/* ${BASEDIR}/usr/local/$d
done
echo "[INFO] tidying up ..."
rm -fr temp

#-------------------------------------------------------------------------
#	Set up symbolic links to keep any scripts using
#	absolute paths happy.
#-------------------------------------------------------------------------

PWD=`pwd`
cd $1/bin
#  At the moment this is causing a problem - not sure why!
#  Commenting it out leaves new version on search path, Original on absolute.
# rm -f grep;   ln -s /usr/local/bin/grep grep
cd $PWD

#-------------------------------------------------------------------------
#	Inform user about additional files included in package
#-------------------------------------------------------------------------


echo ""
echo "*********************************************************************"
echo "    ${PACKAGE} upgrade finished"
echo "*********************************************************************"
echo ""

exit 0

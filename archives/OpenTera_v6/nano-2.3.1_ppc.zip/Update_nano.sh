#!/bin/sh
#
#    Name:         Update_nano.sh
#
#    Description:  Install the GNU nano package for the following
#
#                    OpenTera      Original
#                                  Home Server
#                                  Pro
#                  Should also work for
#                    OpenLink      LS1
#                                  HG
#                  Designed to be called from a master script that is
#                  controlling the overall upgrade.  Assumes that the
#                  script is being called from the root of the image
#                  it is trying to update
#
#    Change History:
#       27 Jul 2011	itimpi	     first version

# The script can take one parameter which is the 'root' directory
# relative to which the changes must be applied.  If omitted then
# the update is relative to /

BASEDIR=$1

PACKAGE=`ls nano*.tgz`

echo ""  
echo "*********************************************************************"
echo "****** ${PACKAGE} install starting"
echo "*********************************************************************"
echo ""
echo "[INFO] BASEDIR=$BASEDIR"/
echo "[INFO] PACKAGE=$PACKAGE"
echo ""


#----------------------------------------------------------------------------
#	Install the new binary and its associated links
#----------------------------------------------------------------------------

#----------------------------------------------------------------------------
#	Install the new binary and its associated links
#	We use a extract/copy method to avoid destroying
#	any symbolic links on the destination.
#----------------------------------------------------------------------------

echo "[INFO] unpacking ${PACKAGE} archive..."
mkdir temp
tar -xzf ${PACKAGE} --directory=temp
echo "[INFO] installing ..."
for d in `ls temp`
do
	cp -pr temp/$d/* ${BASEDIR}/usr/local/$d
done
echo "[INFO] tidying up ..."
rm -fr temp

#-------------------------------------------------------------------------
#	Set up symbolic links to keep any scripts using
#	absolute paths happy.  This ensures that the
#	version of any command is used system wide, and
#	as a by-product frees up some space.  
#	It also replaces busybox variants with full version.
#-------------------------------------------------------------------------

echo "[INFO] Creating symbolic links"
PWD=`pwd`
cd $1/usr/bin
for i in nano
do
	if [ -f $i ]
	then 
		rm -f $i    ; ln -s /usr/local/bin/$i $i
	fi
done
cd $PWD

#-------------------------------------------------------------------------
#	Inform user about additional files included in package
#-------------------------------------------------------------------------

echo ""

echo "*********************************************************************"
echo "    ${PACKAGE} install finished"
echo "*********************************************************************"
echo ""

exit 0

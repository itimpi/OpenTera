#!/bin/sh
#
#    Name:         Update_coreutils.sh
#
#    Description:  Implement the latest less for the following
#
#                    OpenTera      Original
#                                  Home Server
#                                  Pro
#                  Should also work for
#                    OpenLink      LS1
#                                  HG
#                  Designed to be called from a master script that is
#                  controlling the overall upgrade.  Assumes that the
#                  script is being called from the root of the image
#                  it is trying to update
#
#    Change History:
#       03 Mar 2010	itimpi	     first version for OpenTera v3 (coreutils 8.4)
#
#	29 Apr 2010	itimpi	     - Changed to be independent of version of .tgz file

# The script can take one parameter which is the 'root' directory
# relative to which the changes must be applied.  If omitted then
# the update is relative to /

BASEDIR=$1

# Version of the busybox binary that this script relates to.
# This is a check to avoid setting up links that are not
# appropriate for a particular build of the busybox binary.

PACKAGE=`ls coreutils*gz`

echo ""  
echo "*********************************************************************"
echo "****** ${PACKAGE} upgrade starting"
echo "*********************************************************************"
echo ""
echo "[INFO] BASEDIR=$BASEDIR"/
echo "[INFO] PACKAGE=$PACKAGE"
echo ""

if (test -f PPC/${PACKAGE}) 
then
    PACKAGE = "PPC/${PACKAGE}"
elif (test ! -f ${PACKAGE}) then
    echo "[ERROR] You need to first get the ${PACKAGE} package" 
    echo "[INFO] **** ABORTING ${PACKAGE} upgrade ****"
    exit 1
fi

#----------------------------------------------------------------------------
#	Install the new binary and its associated links
#	We use a extract/copy method to avoid destroying
#	any symbolic links on the destination.
#----------------------------------------------------------------------------

echo "[INFO] unpacking ${PACKAGE} archive..."
mkdir temp
tar -xzf ${PACKAGE} --directory=temp
echo "[INFO] installing ..."
# Ensure the included cp has the correct permissions
chown root cp
chgrp root cp
chmod 755 cp
for d in `ls temp`
do
	# Use included cp so that target one can be overwritten
	./cp -pr temp/$d/* ${BASEDIR}/usr/local/$d
done
echo "[INFO] tidying up ..."
rm -fr temp

#-------------------------------------------------------------------------
#	Set up symbolic links to keep any scripts using
#	absolute paths happy.  This ensures that the
#	version of any command is used system wide, and
#	as a by-product frees up some space.  
#	It also replaces busybox variants with full version.
#-------------------------------------------------------------------------

echo "[INFO] Creating symbolic links"
PWD=`pwd`
cd $1/bin
rm -f cat     ; ln -s /usr/local/bin/cat cat
rm -f addgrp  ; ln -s /usr/local/bin/addgrp addgrp
rm -f chgrp   ; ln -s /usr/local/bin/chgrp chgrp
rm -f chmod   ; ln -s /usr/local/bin/chmod chmod
rm -f cp      ; ln -s /usr/local/bin/cp cp
rm -f cut     ; ln -s /usr/local/bin/cut cut
rm -f date    ; ln -s /usr/local/bin/date date
rm -f dd      ; ln -s /usr/local/bin/dd dd
rm -f df      ; ln -s /usr/local/bin/df df
rm -f dirname ; ln -s /usr/local/bin/dirname dirname
rm -f echo    ; ln -s /usr/local/bin/echo echo
rm -f false   ; ln -s /usr/local/bin/false false
rm -f fold    ; ln -s /usr/local/bin/fold fold
rm -f kill    ; ln -s /usr/local/bin/kill kill
rm -f ln      ; ln -s /usr/local/bin/ln ln
rm -f ls      ; ln -s /usr/local/bin/ls ls
rm -f md5sum  ; ln -s /usr/local/bin/md5sum md5sum
rm -f mkdir   ; ln -s /usr/local/bin/mkdir mkdir
rm -f mknod   ; ln -s /usr/local/bin/mknod mknod
rm -f mktemp  ; ln -s /usr/local/bin/mktemp mktemp
rm -f mv      ; ln -s /usr/local/bin/mv mv
rm -f nice    ; ln -s /usr/local/bin/nice nice
rm -f od      ; ln -s /usr/local/bin/od od
rm -f printenv; ln -s /usr/local/bin/printenv printenv
rm -f pwd     ; ln -s /usr/local/bin/pwd pwd
rm -f readlink; ln -s /usr/local/bin/readlink readlink
rm -f rm      ; ln -s /usr/local/bin/rm rm
rm -f rmdir   ; ln -s /usr/local/bin/rmdir rmdir
rm -f sha1sum ; ln -s /usr/local/bin/sha1sum sha1sum
rm -f sleep   ; ln -s /usr/local/bin/sleep sleep
rm -f sort    ; ln -s /usr/local/bin/sort sort
rm -f stat    ; ln -s /usr/local/bin/stat stat
rm -f stty    ; ln -s /usr/local/bin/stty stty
rm -f sync    ; ln -s /usr/local/bin/sync sync
rm -f tee     ; ln -s /usr/local/bin/tee tee
rm -f test    ; ln -s /usr/local/bin/test test
rm -f touch   ; ln -s /usr/local/bin/touch touch
rm -f true    ; ln -s /usr/local/bin/true true
rm -f uname   ; ln -s /usr/local/bin/uname uname
rm -f uniq    ; ln -s /usr/local/bin/uniq uniq
rm -f whoami  ; ln -s /usr/local/bin/whoami whoami
rm -f yes     ; ln -s /usr/local/bin/yes yes

cd $1/usr/bin
rm -f cksum   ; ln -s /usr/local/bin/cksum cksum
rm -f cut     ; ln -s /usr/local/bin/cut cut
rm -f dirname ; ln -s /usr/local/bin/dirname dirname
rm -f du      ; ln -s /usr/local/bin/du du
rm -f env     ; ln -s /usr/local/bin/env env
rm -f expand  ; ln -s /usr/local/bin/expand expand
rm -f fold    ; ln -s /usr/local/bin/fold fold
rm -f head    ; ln -s /usr/local/bin/head head
rm -f hostid  ; ln -s /usr/local/bin/hostid hostid
rm -f install ; ln -s /usr/local/bin/install install
rm -f logname ; ln -s /usr/local/bin/logname logname
rm -f md5sum  ; ln -s /usr/local/bin/md5sum md5sum
rm -f mkfifo  ; ln -s /usr/local/bin/mkfifo mkfifo
rm -f nice    ; ln -s /usr/local/bin/nice nice
rm -f nohup   ; ln -s /usr/local/bin/nohup nohup 
rm -f od      ; ln -s /usr/local/bin/od od
rm -f readlink; ln -s /usr/local/bin/readlink readlink
rm -f seq     ; ln -s /usr/local/bin/seq seq
rm -f sha512sum; ln -s /usr/local/bin/sha512sum sha512sum
rm -f sort    ; ln -s /usr/local/bin/sort sort
rm -f split   ; ln -s /usr/local/bin/split split
rm -f tac     ; ln -s /usr/local/bin/tac tac
rm -f tail    ; ln -s /usr/local/bin/tail tail
rm -f tee     ; ln -s /usr/local/bin/tee tee
rm -f test    ; ln -s /usr/local/bin/test test
rm -f tr      ; ln -s /usr/local/bin/tr tr
rm -f tty     ; ln -s /usr/local/bin/tty tty
rm -f unexpand; ln -s /usr/local/bin/unexpand unexpand
rm -f uniq    ; ln -s /usr/local/bin/uniq uniq
rm -f uptime  ; ln -s /usr/local/bin/uptime uptime
rm -f wc      ; ln -s /usr/local/bin/wc wc
rm -f who     ; ln -s /usr/local/bin/who who
rm -f whoami  ; ln -s /usr/local/bin/whoami whoami
rm -f yes     ; ln -s /usr/local/bin/yes yes

cd $PWD

#-------------------------------------------------------------------------
#	Inform user about additional files included in package
#-------------------------------------------------------------------------

echo ""

echo "*********************************************************************"
echo "    ${PACKAGE} upgrade finished"
echo "*********************************************************************"
echo ""

exit 0

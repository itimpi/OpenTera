#!/bin/sh
#
#    Name:         update_zlib.sh
#
#    Description:  Implement the latest rsync for the following
#
#                    OpenTera      Original
#                                  Home Server
#                                  Pro
#                  Should also work for
#                    OpenLink      LS1
#                                  HG
#                  Designed to be called from a master script that is
#                  controlling the overall upgrade.  Assumes that the
#                  script is being called from the root of the image
#                  it is trying to update
#
#    Change History:
#       03 April 2010	itimpi	- first version for OpenTera (zlib 1.2.4)

# The script can take one parameter which is the 'root' directory
# relative to which the changes must be applied.  If omitted then
# the update is relative to /

BASEDIR=$1

# Version of the busybox binary that this script relates to.
# This is a check to avoid setting up links that are not
# appropriate for a particular build of the busybox binary.

PACKAGE=`ls zlib*.tgz`

echo ""  
echo "*********************************************************************"
echo "     ${PACKAGE} upgrade starting"
echo "*********************************************************************"
echo ""
echo "[INFO] BASEDIR=$BASEDIR"
echo "[INFO] PACKAGE=$PACKAGE"
echo ""


#----------------------------------------------------------------------------
#	Install the new binary and its associated links
#	We use a extract/copy method to avoid destroying
#	any symbolic links on the destination.
#----------------------------------------------------------------------------

echo "[INFO] unpacking ${PACKAGE} archive..."
mkdir temp
tar -xzf ${PACKAGE} --directory=temp
echo "[INFO] installing ..."
for d in `ls temp`
do
	cp -pr temp/$d/* ${BASEDIR}/usr/local/$d
done
echo "[INFO] tidying up ..."
rm -fr temp


#------------------------------------------------------------
#	Set up symbolic links to keep any scripts 
#	or binaries using absolute paths happy.
#------------------------------------------------------------

PWD_SAVE=`pwd`
cd  ${BASEDIR}/usr/lib
rm -f libz.so;      	ln -s /usr/local/lib/libz.so libz.so	
rm -f libz.so.1;	ln -s /usr/local/lib/libz.so.1 libz.so.1
rm -f libz.so.1.1.4;	ln -s libz.so libz.so.1.1.4
cd $PWD_SAVE

#-------------------------------------------------------------------------
#	Inform user about additional files included in package
#-------------------------------------------------------------------------

echo ""

echo "*********************************************************************"
echo "    ${PACKAGE} upgrade finished"
echo "*********************************************************************"
echo ""

exit 0

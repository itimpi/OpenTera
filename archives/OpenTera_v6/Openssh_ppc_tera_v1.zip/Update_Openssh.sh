#!/bin/sh
#
#    Name:         Update_Openssh.sh
#
#    Description:  Copy across and install Openssh files for the following
#                    OpenTera      Original
#                                  Home Server
#                                  Pro
#                  Designed to be called from a master script that is
#                  controlling the overeall upgrade.  Assumes that the
#                  script is being called from the root of the image
#                  it is trying to update.
#                  In fact for all machines except the Pro models this
#		   update has little effect except to correct the rather
#		   annoying bug where the date/time field displayed
#
#    Change History:
#	10 Apr 2007	itimpi       first version


# The script can take one parameter which is the 'root' directory
# relative to which the changes must be applied.  If omitted then
# the update is relative to /

BASEDIR=$1
VERBOSE="-v"

OPENSSH_FILES="OpenSSH-4.3p2_ppc.tar.tgz"

echo ""  
echo "*********************************************************************"
echo "*********************************************************************"  
echo "****************       OpenSSH upgrade starting                ******"
echo "*********************************************************************"
echo "*********************************************************************"
echo ""

echo "" 
# echo "#####################################################################"
# echo "#                                                                   #"
# echo "#                Adding new/updated binaries                        #"
# echo "#                                                                   #"
# echo "#####################################################################"
# echo ""

# If start up files already exist then stop daemon during upgrade

if ( test -f /etc/init.d/sshd ) then
	echo "[INFO] Stopping OpenSSH Daemons"
	/etc/init.d/sshd "stop"
fi

# Install Binaries

SAVEPWD=`pwd`
cd `echo "${BASEDIR}/"`

if (test -f ${SAVEPWD}/PPC/${OPENSSH_FILES}) then
    echo "[INFO] Installing PCAST files" 
    tar -xzf ${SAVEPWD}/PPC/${OPENSSH_FILES}
elif (test -f ${SAVEPWD}/${OPENSSH_FILES}) then
    echo "[INFO] Installing OPENSSH files" 
    tar -xzf ${SAVEPWD}/${OPENSSH_FILES}
else
    cd ${SAVEPWD}
    echo "[ERROR] You need to first get the OpenSSH files ${OPENSSH_FILES}" 
    echo "**** Aborting OpenSSH upgrade ****"
    cd ${SAVEPWD}
    exit 1
fi
cd ${SAVEPWD}

# Copy the 'groups' command (from coreutils 6.7)in if not already present

if ( test ! -f /usr/local/bin/groups ) then
    cp groups ${BASEDIR}/usr/local/bin
    chown root ${BASEDIR}/usr/local/bin/groups
    chgrp root ${BASEDIR}/usr/local/bin/groups
    chmod 755 ${BASEDIR}/usr/local/bin/groups
fi

#	copy the modifed startup file

cp sshd ${BASEDIR}/etc/init.d
chown root ${BASEDIR}/etc/init.d/sshd
chgrp root ${BASEDIR}/etc/init.d/sshd
chmod 755 ${BASEDIR}/etc/init.d/sshd

    
# Fix permissions issues on daemon

chown root ${BASEDIR}/usr/local/sbin/sshd
chgrp root ${BASEDIR}/usr/local/sbin/sshd

#   check for the empty directory and create it if needed
#   (should not now be required as in modified startup file)
#
#if ( test ! -d ${BASEDIR}/var/empty) then
#    mkdir /var/empty
#    chown root:sys /var/empty
#    chmod 755 /var/empty
#fi

# Add the missing startup link if needed

if ( test ! -f ${BASEDIR}/etc/rc.d/rc3.d/S07sshd ) then
    cd ${BASEDIR}/etc/rc.d/rc3.d
    ln ../../init.d/sshd S07sshd
    cd ${SAVEPWD}
fi

# See if we need to generate keys, and if so do this

cd ${BASEDIR}/usr/local/etc/
if ( test -f ssh_host_dsa_key.pub ) then
    echo "[INFO] Found ssh keys already in ${BASEDIR}/usr/local/etc"
    echo "[INFO] If new ones are required you need to run the commands"
    echo "[INFO]   cd ${BASEDIR}/usr/local/etc"
    echo "[INFO]   ./create_keys.sh"
else
    echo "[INFO] Creating new keys in ${BASEDIR}/usr/local/etc"
    ./create_keys.sh
    echo "[INFO] Key generation completed"
    echo "[INFO] You may want to make a note of the key fingerprints above for future reference"
fi
cd ${SAVEPWD}

echo "[INFO] Starting OpenSSH Daemon"
/etc/init.d/sshd "start" 

echo ""
echo "[INFO] You should now be able to connect using your favorite ssh client"
echo ""
echo "[INFO] If you want to disable standard telnet, then edit the file /etc/inetd.conf"
echo "[INFO] and comment out the line to start telnet by inserting a # at the front"
echo ""


echo ""  
echo "*********************************************************************"  
echo "*********************************************************************"
echo "******             OpenSSH upgrade finished                    ******"
echo "*********************************************************************"
echo "*********************************************************************"
echo ""

exit 0

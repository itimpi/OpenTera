#!/bin/sh
#
#    Name:         Update_libiconv.sh
#
#    Description:  Install the libiconv package
#
#                  Relevant to the following:
#
#                    OpenTera      Original
#                                  Home Server
#                                  Pro v1
#                  Should also work for
#                    OpenLink      LS1
#                                  HG
#                  Designed to be called from a master script that is
#                  controlling the overall upgrade.  Assumes that the
#                  script is being called from the root of the image
#                  it is trying to update
#
#    Change History:
#       10 Jan 2010	itimpi	     first version for OpenTera
#				     - Install of ldconfig if not already there

# The script can take one parameter which is the 'root' directory
# relative to which the changes must be applied.  If omitted then
# the update is relative to /


BASEDIR=$1

PACKAGE="libiconv-1.13.1_ppc.tgz"

echo ""
echo "=============== libiconv Install Starting ================="
echo ""

#---------------- ldcondif check/install ----------------
# Check that the ldconfig is either installed or the binaries package available
if ( test ! -f ${BASEDIR}/usr/local/sbin/ldconfig ) 
then
	if ( test ! -f ldconfig-binaries-ppc.tar.gz )
	then
		echo "[INFO] You need the 'ldconfig-binaries-ppc.tar.gz' file"
		exit 1
	fi
	echo "[INFO] Installing ldconfig"
	tar -xzf ldconfig-binaries-ppc.tar.gz --directory=${BASEDIR}/
fi

if ( test -f ${BASEDIR}/etc/ld.so.conf )
then
	grep -q "/usr/local/lib" ${BASEDIR}/etc/ld.so.conf || echo "/usr/local/lib" >> ${BASEDIR}/etc/ld.so.conf
else
	echo "/usr/local/lib" > ${BASEDIR}/etc/ld.so.conf
fi



#---------------- main package install -----------------------
#	We use an unpack/copy technique to avoid clobbering
#	any directory symbolic links that might exist in target
#	(this is one way of freeing space on system partition)
#---------------- main package install -----------------------

echo "[INFO] Processing ${PACKAGE} archive"
echo "[INFO] unpacking ..."
mkdir temp
tar -xzf ${PACKAGE} --directory=temp
echo "[INFO] installing ..."
for d in `ls temp`
do
	# Ensure that required target folder exists
	if [ -d temp/$d ]
	then
		if [ ! -d ${BASEDIR}/usr/$d -a ! -h ${BASEDIR}/usr/$d ]
		then
			mkdir ${BASEDIR}/usr/$d
		fi
	fi

	cp -pr temp/$d/* ${BASEDIR}/usr/$d
done
echo "[INFO] tidying up ..."
rm -fr temp

ldconfig


#------------------------------------------------------------
#	Set up symbolic links (if required) to keep
#	any scripts using absolute paths happy.
#------------------------------------------------------------


PWD_SAVE=`pwd`
cd $1/usr/bin
cd ${PWD_SAVE}

#-------------------------------------------------------------------------
#	Inform user about additional files included in package
#-------------------------------------------------------------------------

# echo ""


echo ""
echo "=============== libiconv Install Completed ================="
echo ""

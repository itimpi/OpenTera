#!/bin/sh
#
#    Name:         Update_findutils.sh
#
#    Description:  Install the GNU findutils package for the following
#
#                    OpenTera      Original
#                                  Home Server
#                                  Pro
#                  Should also work for
#                    OpenLink      LS1
#                                  HG
#                  Designed to be called from a master script that is
#                  controlling the overall upgrade.  Assumes that the
#                  script is being called from the root of the image
#                  it is trying to update
#
#    Change History:
#       03 Mar 2010	itimpi	    - first version for OpenTera v3 (findutils 4.4.2_ppc)
#
#	13 Apr 2010	itimpi	    - Fix to ensure target folders exist for copy

# The script can take one parameter which is the 'root' directory
# relative to which the changes must be applied.  If omitted then
# the update is relative to /

BASEDIR=$1

# Version of the busybox binary that this script relates to.
# This is a check to avoid setting up links that are not
# appropriate for a particular build of the busybox binary.

PACKAGE="findutils-4.4.2_ppc.tgz"

echo ""  
echo "*********************************************************************"
echo "****** ${PACKAGE} upgrade starting"
echo "*********************************************************************"
echo ""
echo "[INFO] BASEDIR=/$BASEDIR"/
echo "[INFO] PACKAGE=$PACKAGE"
echo ""

if (test -f PPC/${PACKAGE}) 
then
    PACKAGE = "PPC/${PACKAGE}"
elif (test ! -f ${PACKAGE}) then
    echo "[ERROR] You need to first get the ${PACKAGE} package" 
    echo "[INFO] **** ABORTING ${PACKAGE} upgrade ****"
    exit 1
fi

#----------------------------------------------------------------------------
#	Install the new binary and its associated links
#----------------------------------------------------------------------------

#----------------------------------------------------------------------------
#	Install the new binary and its associated links
#	We use a extract/copy method to avoid destroying
#	any symbolic links on the destination.
#----------------------------------------------------------------------------

echo "[INFO] unpacking ${PACKAGE} archive..."
mkdir temp
tar -xzf ${PACKAGE} --directory=temp
echo "[INFO] installing ..."
for d in `ls temp`
do
	# Ensure that required target folder exists
	if [ -d temp/$d ]
	then
		if [ ! -d ${BASEDIR}/usr/local/$d -a ! -h ${BASEDIR}/usr/local/$d ]
		then
			mkdir ${BASEDIR}/usr/local/$d
			echo "[INFO] Created folder ${BASEDIR}usr/local/$d"
		fi
	fi
	# Copy across files
	cp -pr temp/$d/* ${BASEDIR}/usr/local/$d
done
echo "[INFO] tidying up ..."
rm -fr temp

#-------------------------------------------------------------------------
#	Set up symbolic links to keep any scripts using
#	absolute paths happy.  This ensures that the
#	version of any command is used system wide, and
#	as a by-product frees up some space.  
#	It also replaces busybox variants with full version.
#-------------------------------------------------------------------------

PWD=`pwd`

cd $1/usr/bin
rm -f find   ; ln -s /usr/local/bin/find find
rm -f xargs  ; ln -s /usr/local/bin/xargs xargs

cd $PWD

#-------------------------------------------------------------------------
#	Inform user about additional files included in package
#-------------------------------------------------------------------------

echo ""

echo "*********************************************************************"
echo "    ${PACKAGE} upgrade finished"
echo "*********************************************************************"
echo ""

exit 0

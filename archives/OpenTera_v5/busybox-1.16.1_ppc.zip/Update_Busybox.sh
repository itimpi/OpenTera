#!/bin/sh
#
#    Name:         update_busybox.sh
#
#    Description:  Implement the latest busybox and set up all
#                  associated links for the following
#
#                    OpenTera      Original
#                                  Home Server
#                                  Pro
#                  Should also work for
#                    OpenLink      LS1
#                                  HG
#                  Designed to be called from a master script that is
#                  controlling the overall upgrade.  Assumes that the
#                  script is being called from the root of the image
#                  it is trying to update
#
#    Change History:
#       20 Dec 2006	itimpi	     first version for OpenTera
#	20 Jan 2007     itimpi       Changed to use V2 binary
#                                    Add rm command in front of each ln command
#                                    Updated list of links to match new 1.4 binary
#	25 Jan 2007     itimpi       Suppressed removal of ip command family links
#                                    Removed assumption that original busybox supports ln
#	26 Jan 2007	itimpi       removed commands for which free-standing binary WILL be kept.
#	18 Oct 2008     itimpi	     Updated to use busybox 1.12.1
#				     Files .config and Excel Busybox Analysis now included
#	16 Nov 2008	itimpi	     Updated to use busybox 1.12.2
#	17 Nov 2008	itimpi	     Updated to use busybox 1.13.0
#	25 May 2009	itimpi       Updated to use busybox 1.13.4
#	26 May 2009	itimpi       Updated to use busybox 1.14.0
#	30 May 2009	itimpi       Updated to use busybox 1.14.1
#	24 Jun 2009	itimpi       Updated to use busybox 1.14.2
#	04 Aug 2009	itimpi       Updated to use busybox 1.14.3
#	25 Aug 2009     itimpi       Updated to use busybox 1.15.0
#	18 Sep 2009     itimpi       Updated to use busybox 1.15.1
#	09 Oct 2009     itimpi       Updated to use busybox 1.15.2
#	24 Dec 2009     itimpi       Updated to use busybox 1.15.3
#	25 Feb 2010	itimpi	     Updated to use busybox 1.16.0
#	30 Mar 2010	itimpi	     Updated to use busybox 1.16.1
#

# The script can take one parameter which is the 'root' directory
# relative to which the changes must be applied.  If omitted then
# the update is relative to /

BASEDIR=$1

# Version of the busybox binary that this script relates to.
# This is a check to avoid setting up links that are not
# appropriate for a particular build of the busybox binary.

BUSYBOX="busybox-1.16.1_ppc.tgz"

echo ""  
echo "*********************************************************************"
echo "****** busybox upgrade starting                                ******"
echo "*********************************************************************"
echo ""
echo "[INFO] BASEDIR=$BASEDIR"
echo "[INFO] BUSYBOX=$BUSYBOX"
echo ""

#----------------------------------------------------------------------------
#	Install the new biary and its associated links
#----------------------------------------------------------------------------

echo "[INFO] Installing new busybox"

# Unpack binaries and links to a temporary location
# This is needed as unpacking direct to a live location fails.
mkdir temp
tar -xzf ${BUSYBOX} --directory=temp

# Remove any links for commands which have full versions
# installed by default, and are only included in this
# busybox binary to help with testing the busybox variant
# for it becoming standard in future releases
rm -f temp/sbin/man
rm -f temp/usr/bin/ar
rm -f temp/sbin/ifconfig

# Copy files into their final location
cp -af temp/* ${BASEDIR}/

# Remove temporary files
rm -fr temp

# Ensure owner and permissions correct
chown root ${BASEDIR}/bin/busybox
chgrp root ${BASEDIR}/bin/busybox
chmod 4755 ${BASEDIR}/bin/busybox


#----------------------------------------------------------------------------
#  In standard TeraStation/LinkStation build certain commands seem to be at
#  more than one location.   To ensure compatibility with the Buffalo perl
#  scripts (that often use absolute paths) we set up some duplicate links.
#  To make it more obvious these are duplicates we link to the correct location.
#----------------------------------------------------------------------------

echo "[INFO] Adding new busybox links"

PWD_SAVE=`pwd`
cd ${BASEDIR}/bin

rm -f bunzip2;     ln -s ../usr/bin/bunzip2
rm -f bzcat;       ln -s ../usr/bin/bzcat
rm -f clear;       ln -s ../usr/bin/clear
rm -f dirname;     ln -s ../usr/bin/dirname
rm -f dos2unix;    ln -s ../usr/bin/dos2unix
rm -f dpkg;        ln -s ../usr/bin/dpkg
rm -f dpkg-deb;    ln -s ../usr/bin/dpkg-deb
rm -f fold;        ln -s ../usr/bin/fold
rm -f hexdump;     ln -s ../usr/bin/hexdump
rm -f lsmod;       ln -s ../sbin/lsmod
rm -f md5sum;      ln -s ../usr/bin/md5sum
rm -f modprobe;    ln -s ../sbin/modprobe
rm -f nohup;       ln -s ../usr/bin/nohup
rm -f nslookup;    ln -s ../usr/bin/nslookup
rm -f od;          ln -s ../usr/bin/od
rm -f openvt;      ln -s ../usr/bin/openvt
rm -f patch;       ln -s ../usr/bin/patch
rm -f readlink;    ln -s ../usr/bin/readlink
rm -f renice;      ln -s ../usr/bin/renice
rm -f rpm2cpio;    ln -s ../usr/bin/rpm2cpio
rm -f sha1sum;     ln -s ../usr/bin/sha1sum
rm -f sort;        ln -s ../usr/bin/sort
rm -f tee;         ln -s ../usr/bin/tee
rm -f test;        ln -s ../usr/bin/test
rm -f time;        ln -s ../usr/bin/time
rm -f traceroute;  ln -s ../usr/bin/traceroute
rm -f uniq;        ln -s ../usr/bin/uniq
rm -f unix2dos;    ln -s ../usr/bin/unix2dos
rm -f uudecode;    ln -s ../usr/bin/uudecode
rm -f uuencode;    ln -s ../usr/bin/uuencode
rm -f wget;        ln -s ../usr/bin/wget
rm -f whoami;      ln -s ../usr/bin/whoami
rm -f yes;         ln -s ../usr/bin/yes

cd ${BASEDIR}/usr/bin

rm -f fsck;        ln -s ../../sbin/fsck
rm -f nice;        ln -s ../../bin/nice
rm -f rpm;         ln -s ../../bin/rpm
rm -f watch;       ln -s ../../bin/watch

cd ${BASEDIR}/sbin

cd ${BASEDIR}/usr/sbin

cd "${PWD_SAVE}"
pwd

# echo "#####################################################################"
# echo "#                                                                   #"
# echo "#                     Removing unneeded stuff                       #"
# echo "#                                                                   #"
# echo "#####################################################################"
# echo ""

# Remove any old busybox binaries if present

rm -f ${BASEDIR}/bin/busybox_1.4.0_enhanced?static_v2
rm -f ${BASEDIR}/bin/busybox_1.4.0_enhanced_static_v3
rm -f ${BASEDIR}/bin/busybox_1.4.1_patched_static_v1
rm -f ${BASEDIR}/bin/busybox_1.4.1_patched_static_v4
rm -f ${BASEDIR}/bin/busybox_1.5.0_ppc_dynamic_v6


#-------------------------------------------------------------------------
#	Inform user about additional files included in package
#-------------------------------------------------------------------------

echo ""
echo "[INFO] There are some additional files included in the install folder:"
echo "[INFO] - " `ls *.xls` ":An Excel spreadsheet that gives an"
echo "[INFO]                               analysis of what is in this busybox"
echo "[INFO] - .config:  The configuration file used when building this busybox"
echo "                   from source."
echo ""
echo "[INFO] for more information on busybox visit http://www.busybox.net"
echo ""  
echo "*********************************************************************"
echo "****** busybox upgrade finished.                               ******"
echo "*********************************************************************"
echo ""

exit 0

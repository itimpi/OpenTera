#!/bin/sh
#
#    Name:         Update_zip.sh
#
#    Description:  Implement the latest zip/unzip packages for the following
#
#                    OpenTera      Original
#                                  Home Server
#                                  Pro
#                  Should also work for
#                    OpenLink      LS1
#                                  HG
#                  Designed to be called from a master script that is
#                  controlling the overall upgrade.  Assumes that the
#                  script is being called from the root of the image
#                  it is trying to update
#
#    Change History:
#       03 MarFeb 2010	itimpi	     first version for OpenTera v3 (grep 2.5.4)

# The script can take one parameter which is the 'root' directory
# relative to which the changes must be applied.  If omitted then
# the update is relative to /

BASEDIR=$1

# Version of the busybox binary that this script relates to.
# This is a check to avoid setting up links that are not
# appropriate for a particular build of the busybox binary.

PACKAGE="zip30_ppc.tgz"
PACKAGE2="unzip60_ppc.tgz"

echo ""  
echo "*********************************************************************"
echo "          ${PACKAGE} and ${PACKAGE2} upgrade starting"
echo "*********************************************************************"
echo ""
echo "[INFO] BASEDIR=/$BASEDIR"/
echo "[INFO] PACKAGE=$PACKAGE"
echo ""

if (test -f PPC/${PACKAGE}) 
then
    PACKAGE = "PPC/${PACKAGE}"
elif (test ! -f ${PACKAGE}) then
    echo "[ERROR] You need to first get the ${PACKAGE} package" 
    echo "[INFO] **** ABORTING ${PACKAGE} upgrade ****"
    exit 1
fi

#---------------- main package install ----------------
#	We use an unpack/copy technique to avoid clobbering
#	any directory symbolic links that might exist in target
#	(this is one way of freeing space on system partition)

echo "[INFO] Processing ${PACKAGE} archive"
echo "[INFO] unpacking ..."
mkdir temp
tar -xzf ${PACKAGE} --directory=temp
echo "[INFO] installing ..."
for d in `ls temp`
do
	cp -pr temp/$d/* ${BASEDIR}/usr/local/$d
done
echo "[INFO] tidying up ..."
rm -fr temp


echo "[INFO] Processing ${PACKAGE2} archive"
echo "[INFO] unpacking ..."
mkdir temp
tar -xzf ${PACKAGE2} --directory=temp
echo "[INFO] installing ..."
for d in `ls temp`
do
	cp -pr temp/$d/* ${BASEDIR}/usr/local/$d
done
echo "[INFO] tidying up ..."
rm -fr temp

#-------------------------------------------------------------------------
#	Set up symbolic links to keep any scripts using
#	abosulte paths happy.
#-------------------------------------------------------------------------

PWD=`pwd`
cd $1/usr/bin
rm -f unzip
ln -s /usr/local/bin/unzip unzip
cd $PWD

#-------------------------------------------------------------------------
#	Inform user about additional files included in package
#-------------------------------------------------------------------------


echo ""
echo "*********************************************************************"
echo "          ${PACKAGE} and ${PACKAGE2} upgrade finished"
echo "*********************************************************************"
echo ""

exit 0

#!/bin/sh
#
#    Name:         Update_ushare.sh
#
#    Description:  Install the ushare package
#
#                  Relevant to the following:
#
#                    OpenTera      Original
#                                  Home Server
#                                  Pro v1
#                  Should also work for
#                    OpenLink      LS1
#                                  HG
#                  Designed to be called from a master script that is
#                  controlling the overall upgrade.  Assumes that the
#                  script is being called from the root of the image
#                  it is trying to update
#
#    Change History:
#       14 Aug 2009	itimpi	     first version for OpenTera
#	24 Dec 2009     itimpi       Updated to include:
#				     - Install of ldconfig if not already there
#				     - Checks that libupnp and libdlna packages installed
#	31 Jan 2010	itimpi	     Fixed issue that could cause loss of start-up files.
#	24 Mar 2010	itimpi	     Ushare updated with patches pointed out by Entropy and located at:
#					http://hg.geexbox.org/ushare/rev/15a916aac837
#					http://lists.rpmfusion.org/pipermail/rpmfusion-commits/2008-September/001529.html

# The script can take one parameter which is the 'root' directory
# relative to which the changes must be applied.  If omitted then
# the update is relative to /


BASEDIR=$1

USHARE_PKG=`ls ushare*.tgz`

echo ""
echo "=============== uShare Install Starting ================="
echo ""
echo "BASEDIR=${BASEDIR}"
echo "USHARE_PKG=${USHARE_PKG}"

#---------------- ldcondif check/install ----------------
# Check that the ldconfig is either installed or the binaries package available
if [ ! -f ${BASEDIR}/usr/local/sbin/ldconfig ] 
then
	if [ ! -f ldconfig-binaries-ppc.tar.gz ]
	then
		echo "[INFO] You need the 'ldconfig-binaries-ppc.tar.gz' file"
		exit 1
	fi
	echo "[INFO] Installing ldconfig"
	tar -xzf ldconfig-binaries-ppc.tar.gz --directory=${BASEDIR}/
fi

if [ -f ${BASEDIR}/etc/ld.so.conf ]
then
	grep -q "/usr/local/lib" ${BASEDIR}/etc/ld.so.conf || echo "/usr/local/lib" >> ${BASEDIR}/etc/ld.so.conf
else
	echo "/usr/local/lib" > ${BASEDIR}/etc/ld.so.conf
fi
ldconfig

#---------------- main ushare install ----------------
if [ -f /etc/init.d/ushare ] 
then
	if [ -f /etc/ushare.conf ]
	then
		echo "[INFO] Stopping ushare service"
		/etc/init.d/ushare stop 
	fi
fi

echo "[INFO] ushare is available both with and without DLNA support"
answer=""
while ( test "$answer" != "y" -a "$answer" != "n" ) ; do
	echo "Do you want the DLNA support (y/n)"
	read answer
done

echo "[INFO] Checking dependencies"

# Check for libupnp installed
# (always required)
if [ -f ${BASEDIR}/usr/local/lib/libupnp.so ]
then
	echo "[INFO] UPNP dependancies appear OK"
else
	echo "[INFO] UPNP dependancies appear to be missing"
	echo "[INFO] Please install the LibUPNP package before installing ushare"
	echo ""
	echo "=============== uShare Install Aborted ================="
	echo ""
	exit 1
fi

if [ "$answer" = "y" ]
then
	# Check for libdlna installed
	# (if DLNA ushare required)
	if [test -f ${BASEDIR}/usr/local/lib/libdlna.so ]
	then
		echo "[INFO] DLNA dependancies appear OK"
	else
		echo "[INFO] DLNA dependancies appear to be missing"
		echo "[INFO] Please install the LibDLNA package before installing ushare"
		echo ""
		echo "=============== uShare Install Aborted ================="
		echo ""
		exit 1
	fi
fi


echo "[INFO] Installing ushare binary and start-up files"
mkdir temp
echo "[INFO] Processing ${USHARE_PKG} archive"
echo "[INFO] unpacking ..."
tar -xzf ${USHARE_PKG} --directory=temp
chown -R root temp
chgrp -R root temp
echo "[INFO] installing ..."
cp -pr temp/etc/* ${BASEDIR}/etc
cp -pr temp/usr/local/bin/* ${BASEDIR}/usr/local/bin
cp -pr temp/usr/local/share/* ${BASEDIR}/usr/local/share
echo "[INFO] tidying up ..."
rm -fr temp


echo ""
echo "[INFO] Both the dlna and none-dlna binaries are in ${BASEDIR}/usr/local/bin"
echo "[INFO] You can switch between them by changing which version the"
echo "[INFO] symbolic link '/usr/local/bin/ushare' points to"
echo ""

rm -f /usr/local/bin/ushare
if [ "$answer" = "n" ]
then
	ln -s /usr/local/bin/ushare-nodlna /usr/local/bin/ushare
else
	ln -s /usr/local/bin/ushare-dlna /usr/local/bin/ushare
fi

if [ -f /etc/ushare.conf ] 
then
	echo "[INFO] Restarting ushare service"
	/etc/init.d/ushare restart 
else
	echo ""
	echo "[INFO] You need to configure ${BASEDIR}/etc/ushare.conf"
	echo "[INFO] There is a sample file in ${BASEDIR}/etc/ushare.conf_sample"
fi

if [ -f /etc/init.d/pcastd ]
then
	echo ""
	echo "[CAUTION] You should not run uShare and PCast at the same time"
fi

echo ""
echo "=============== uShare Install Completed ================="
echo ""

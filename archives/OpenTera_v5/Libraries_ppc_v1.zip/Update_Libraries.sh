#!/bin/sh
#
#    Name:         Update_Libraries.sh
#
#    Description:  Update libraries
#                    OpenTera      Original
#                                  Home Server
#                                  Pro
#                  Designed to be called from a master script that is
#                  controlling the overall upgrade.  
#
#    Change History:
#       11 Jan 2007	itimpi	     first version for OpenTera
#	14 Mar 2007	itimpi	     First version made generally available
#


# The script can take one parameter which is the 'root' directory
# relative to which the changes must be applied.  If omitted then
# the update is relative to /

BASEDIR=$1

echo ""  
echo "*********************************************************************"  
echo "*********************************************************************"
echo "****** Libary upgrade starting                                 ******"
echo "*********************************************************************"
echo "*********************************************************************"
echo ""

 

echo "" 
echo "#####################################################################"
echo "#                                                                   #"
echo "#                Adding new/updated libraries                       #"
echo "#                                                                   #"
echo "#####################################################################"
echo ""

echo "[INFO] Stopping services while updating libraries"
/etc/init.d/smb "stop"
 
SAVEPWD=`pwd`
cd `echo "${BASEDIR}/"`
echo "Installation is relative to ${BASEDIR}/"

#   Libaries already on system so not needing to be added:
#    libssl0.9.7_0.9.7e-3sarge4_powerpc.deb.tgz 

#   Libraries to be added, but not yet checked out
#    libcupsys2_1.1.23-10sarge1_all.deb.tgz \
#    libcupsys2-gnutls10_1.1.23-10sarge1_powerpc.deb.tgz \

for CURRENTLIB in \
    krb5-config_1.6_all.deb.tgz \
    krb5-doc_1.3.6-2sarge3_all.deb.tgz \
    krb5-user_1.3.6-2sarge3_powerpc.deb.tgz \
    libattr1_2.4.16-1_powerpc.deb.tgz \
    libacl1_2.2.23-1_powerpc.deb.tgz \
    libcomerr2_1.37-2sarge1_powerpc.deb.tgz \
    libdb3_3.2.9-22_powerpc.deb.tgz \
    libdb4.2_4.2.52-18_powerpc.deb.tgz \
    libdb4.3_4.3.27-2_powerpc.deb.tgz \
    libgcrypt11_1.2.0-11.1_powerpc.deb.tgz \
    libgnutls11_1.0.16-13.2sarge2_powerpc.deb.tgz \
    libgpg-error0_1.0-1_powerpc.deb.tgz \
    libkrb53_1.3.6-2sarge3_powerpc.deb.tgz \
    libldap-2.2-7_2.2.23-8_powerpc.deb.tgz \
    libldap2_2.1.30-8_powerpc.deb.tgz \
    libpam-doc_0.76-22_all.deb.tgz \
    libpam0g_0.76-22_powerpc.deb.tgz \
    libpam-cracklib_0.76-22_powerpc.deb.tgz \
    libpam-runtime_0.76-22_all.deb.tgz \
    libpam-smbpass_3.0.14a-3sarge4_powerpc.deb.tgz \
    libsasl2_2.1.19.dfsg1-0sarge2_powerpc.deb.tgz \
    libsasl2-modules_2.1.19.dfsg1-0sarge2_powerpc.deb.tgz \
    libss2_1.37-2sarge1_powerpc.deb.tgz \
    libtasn1-0_0.1.2-5_powerpc.deb.tgz \
    libtasn1-2_0.2.10-3sarge1_powerpc.deb.tgz
do
    if (test -f ${SAVEPWD}/PPC/${CURRENTLIB}) then
        echo "[INFO] Installing $CURRENTLIB" 
        tar -xzf ${SAVEPWD}/PPC/${CURRENTLIB}
    elif (test -f ${SAVEPWD}/${CURRENTLIB}) then
        echo "[INFO] Installing $CURRENTLIB" 
        tar -xzf ${SAVEPWD}/${CURRENTLIB}
    else
        cd ${SAVEPWD}
        echo "[ERROR] You need to first get the $CURRENTLIB binary package" 
        echo "**** Aborting Library upgrade ****"
	/etc/init.d/smb "start"
        exit 1
    fi
done

cd ${SAVEPWD}

# New libraries to new positions
# cp PPC/lib/* ${BASEDIR}/lib
# cp PPC/usr/lib/* ${BASEDIR}/usr/lib
# cp PPC/usr/local/lib/* ${BASEDIR/usr/local/lib

echo "[INFO] Restarting services stopped while updating libraries"
/etc/init.d/smb "start" > /dev/null 2>&1

# echo "" 
# echo "#####################################################################"
# echo "#                                                                   #"
# echo "#                      Updating library links                       #"
# echo "#                                                                   #"
# echo "#####################################################################"
# echo ""
#
# cd ${BASEDIR}/lib
# rm -f ld.so.1;    ln -s libc-2.3.5.so libc.so.6
# ln -s 
# 
# echo ""
# echo "#####################################################################"
# echo "#                                                                   #"
# echo "#                     Removing unneeded stuff                       #"
# echo "#                                                                   #"
# echo "#####################################################################"
# echo ""

echo "** Old libraries not removed at the moment **"
# (when we do we should probably created symbolic links
#  using old names to the new versions).
cd  ${BASEDIR}/lib
# rm -f ld-2.3.2.so
# rm -f libc-2.3.2.so
# rm -f libcrypt-2.3.2.so
# rm -f libd1-2.3.2.so
# rm -f libm-2.3.2.so
# rm -f libncurses.so.5.2
# rm -f libnsl-2.3.2.so
# rm -f libnss_compat-2.3.2.so
# rm -f libnss_dns-2.3.2.so
# rm -f libnss_files-2.3.2.so
# rm -f libnss_hesiod-2.3.2.so
# rm -f libnss_nis-2.3.2.so
# rm -f libnss_nisplus-2.3.2.so
# rm -f libnss_winbind-2.3.2.so
# rm -f libnss_wins-2.3.2.so

#   This section (which hopefully will normally be empty) is used   #
#   to remove any libraries/links that were set up incorrectly in   #
#   previous versions of the scripts and that which would not be    #
#   corrected automatically by the main setup part of the script    #
#
#   
#
# echo "#####################################################"
# echo "#                                                   #"
# echo "#                   Bugfixing                       #"
# echo "#                                                   #"
# echo "#####################################################"

  
# echo "create additional libssl-symlinks (MANTIS bug 00021)..."
# ln -s /usr/lib/libssl.so.0.9.7 /usr/lib/libssl.so.0
# ln -s /usr/lib/libssl.so.0 /usr/lib/libssl.so 
# echo "...done!"
# 
# echo ""
# 
if ( test ! -f /usr/lib/libcrypto.so.0.9.6 ) 
then
    echo "fix a bug with netatalk and missing libssl 0.96 (MANTIS BUG 00011)..."
    ln -s /usr/lib/libcrypto.so.0.9.7 /usr/lib/libcrypto.so.0.9.6
fi

echo "...done!"
exit 0
